export const Skill_data = [
  {
    skill_name: "tm",
    Image: "/tm.png",
    width: 150,
    height: 150,
  },
  {
    skill_name: "CPP",
    Image: "/cpp.png",
    width: 350,
    height: 350,
  },
  /*{
    skill_name: "tm",
    Image: "/tm.png",
    width: 150,
    height: 150,
  },*/
  {
    skill_name: "tm",
    Image: "/tm.png",
    width: 1,
    height: 1,
  },
  {
    skill_name: "wjyl",
    Image: "/wjyl.png",
    width: 300,
    height: 300,
  },
  {
    skill_name: "tm",
    Image: "/tm.png",
    width: 1,
    height: 1,
  },
  {
    skill_name: "ds",
    Image: "/ds.png",
    width: 165,
    height: 165,
  },
  {
    skill_name: "tm",
    Image: "/tm.png",
    width: 20,
    height: 20,
  },
  {
    skill_name: "python",
    Image: "/python.png",
    width: 205,
    height: 205,
  },
  {
    skill_name: "tm",
    Image: "/tm.png",
    width: 1,
    height: 1,
  },
];

export const Backend_skill = [
  {
    skill_name: "d",
    Image: "/d.png",
    width: 280,
    height: 280,
  },
  {
    skill_name: "b",
    Image: "/b.png",
    width: 266,
    height: 266,
  },
  {
    skill_name: "c",
    Image: "/c.png",
    width: 277,
    height: 277,
  },
  {
    skill_name: "a",
    Image: "/a.png",
    width: 440,
    height: 440,
  },
];
